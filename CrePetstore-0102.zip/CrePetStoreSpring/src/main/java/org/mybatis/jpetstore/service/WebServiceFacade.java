package org.mybatis.jpetstore.service;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import java.util.List;

import org.mybatis.jpetstore.domain.Account;
import org.mybatis.jpetstore.domain.Category;
import org.mybatis.jpetstore.domain.Item;
import org.mybatis.jpetstore.domain.Product;
import org.mybatis.jpetstore.domain.Order;
import org.mybatis.jpetstore.domain.CategoryProduct;

//Service Endpoint Interface
@WebService
@SOAPBinding(style = Style.RPC)
public interface WebServiceFacade{
	
	@WebMethod
	Account getAccountByUsername(String username);
	
	@WebMethod
	Account getAccount(String username, String password);
	
	@WebMethod
	void insertAccount(Account account);
	
	@WebMethod
	void updateAccount(Account account);

	@WebMethod
	List<Category> getCategoryList();

	@WebMethod
	Category getCategory(String categoryId);
	
	@WebMethod
	Product getProduct(String productId);

	@WebMethod
	List<Product> getProductListByCategory(String categoryId);
	
	@WebMethod
	List<Product> searchProductList(String keyword);

	@WebMethod
	List<CategoryProduct> getCategoryAndProductList();
	
	@WebMethod
	List<Item> getItemListByProduct(String productId);
	
	@WebMethod
	List<Item> getItemListByCategory(String categoryId);	

	@WebMethod
	Item getItem(String itemId);

	@WebMethod
	boolean isItemInStock(String itemId);

	@WebMethod
	List<Item> getItemList();

	@WebMethod
	void insertOrder(Order order);
	
	@WebMethod
	Order getOrder(int orderId);

	@WebMethod
	List<Order> getOrdersByUsername(String username);
}