package org.mybatis.jpetstore.persistence;

import java.util.List;

import org.mybatis.jpetstore.domain.Product;
import org.mybatis.jpetstore.domain.CategoryProduct;

public interface ProductMapper {

  List<Product> getProductListByCategory(String categoryId);

  Product getProduct(String productId);

  List<Product> searchProductList(String keywords);
  
  /* Query for Flex HTTP Service */
  List<CategoryProduct> getCategoryAndProductList();

}
