package org.mybatis.jpetstore.domain;

import java.io.Serializable;

public class CategoryProduct implements Serializable {

  private static final long serialVersionUID = 1222179582713735628L;
  private String productId;
  private String categoryId;
  private String name;
  private String description;
  
  /* Query for Flex HTTP Service */
  private String categoryName;
  private String categoryDescription;
  private String categoryImage;
  private String productImage;
  private String productDescription;
  
  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId.trim();
  }

  public String getCategoryId() {
    return categoryId;
  }

  public void setCategoryId(String categoryId) {
    this.categoryId = categoryId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String toString() {
    return getName();
  }

  /* JavaBeans Properties For Flex HTTP Service*/
  public String getCategoryName() {
	return categoryName;
  }
  
  public void setCategoryName(String categoryName) {
	this.categoryName = categoryName;
  }
	
  public String getCategoryDescription() {
	int start_point = categoryDescription.lastIndexOf('"');
	int end_point = categoryDescription.lastIndexOf('<');
	return categoryDescription.substring(start_point+2, end_point);
  }
  
  public void setCategoryDescription(String categoryDescription) { 
	this.categoryDescription = categoryDescription; 
  }

  public String getCategoryImage() {
	int start_point = categoryDescription.indexOf('"');
	int end_point = categoryDescription.indexOf("><font");		
	return categoryDescription.substring(start_point+1, end_point-1); 
  }

  public void setCategoryImage(String categoryImage) { 
	this.categoryImage = categoryImage; 
  }

  public String getProductImage() {    
	int start_point = description.indexOf('"');
	int end_point = description.lastIndexOf('"');
	return description.substring(start_point+1, end_point); 
  }

  public void setProductImage(String productImage) { 
    this.productImage = productImage; 
  }
  
  public String getProductDescription() {
	int start_point = description.indexOf('>');            
    return description.substring(start_point+1);    
  }

  public void setProductDescription(String productDescription) { 
    this.productDescription = productDescription; 
  }
  
}
