package org.mybatis.jpetstore.service;

import javax.annotation.Resource;
import javax.jws.WebService;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import org.mybatis.jpetstore.domain.Account;
import org.mybatis.jpetstore.domain.Category;
import org.mybatis.jpetstore.domain.Item;
import org.mybatis.jpetstore.domain.LineItem;
import org.mybatis.jpetstore.domain.Product;
import org.mybatis.jpetstore.domain.Order;
import org.mybatis.jpetstore.domain.Sequence;
import org.mybatis.jpetstore.domain.CategoryProduct;

import org.mybatis.jpetstore.persistence.AccountMapper;
import org.mybatis.jpetstore.persistence.CategoryMapper;
import org.mybatis.jpetstore.persistence.ItemMapper;
import org.mybatis.jpetstore.persistence.ProductMapper;
import org.mybatis.jpetstore.persistence.LineItemMapper;
import org.mybatis.jpetstore.persistence.OrderMapper;
import org.mybatis.jpetstore.persistence.SequenceMapper;

import org.springframework.transaction.annotation.Transactional;


//Service Implementation Bean

@WebService(endpointInterface = "org.mybatis.jpetstore.service.WebServiceFacade")
public class WebServiceImpl implements WebServiceFacade{

	@Resource(name="accountMapper")
    private AccountMapper accountMapper;
	
	@Resource(name="categoryMapper")
    private CategoryMapper categoryMapper;
	
	@Resource(name="orderMapper")
    private OrderMapper orderMapper;
	
	@Resource(name="itemMapper")
    private ItemMapper itemMapper;
	
	@Resource(name="lineItemMapper")
    private LineItemMapper lineItemMapper;

	@Resource(name="productMapper")
    private ProductMapper productMapper;

	@Resource(name="sequenceMapper")
    private SequenceMapper sequenceMapper;

	@Override 
	public Account getAccountByUsername(String username) {
	    return accountMapper.getAccountByUsername(username);
	}
	
	@Override 
	public Account getAccount(String username, String password) {
	    Account account = new Account();
	    account.setUsername(username);
	    account.setPassword(password);
	    return accountMapper.getAccountByUsernameAndPassword(account);
	}

	@Override 
	@Transactional
	public void insertAccount(Account account) {
	    accountMapper.insertAccount(account);
	    accountMapper.insertProfile(account);
	    accountMapper.insertSignon(account);
	}

	@Override 
	@Transactional
	public void updateAccount(Account account) {
	    accountMapper.updateAccount(account);
	    accountMapper.updateProfile(account);

	    if (account.getPassword() != null && account.getPassword().length() > 0) {
	      accountMapper.updateSignon(account);
	    }
	}	

	@Override
	public List<Category> getCategoryList() {
	    return categoryMapper.getCategoryList();
	}

	@Override
	public Category getCategory(String categoryId) {
	    return categoryMapper.getCategory(categoryId);
	}

	@Override
	public Product getProduct(String productId) {
	    return productMapper.getProduct(productId);
	}

	@Override
	public List<Product> getProductListByCategory(String categoryId) {
	    return productMapper.getProductListByCategory(categoryId);
	}

	@Override
	public List<Product> searchProductList(String keyword) {
	    return productMapper.searchProductList("%" + keyword.toLowerCase() + "%");
	}

	@Override		  
	public List<CategoryProduct> getCategoryAndProductList() {
		return productMapper.getCategoryAndProductList();
	}

	@Override
	public List<Item> getItemListByProduct(String productId) {
	    return itemMapper.getItemListByProduct(productId);
	}

	@Override
	public List<Item> getItemListByCategory(String categoryId) {
		return itemMapper.getItemListByCategory(categoryId);
	}
		  
	@Override
	public Item getItem(String itemId) {
	    return itemMapper.getItem(itemId);
	}

	@Override
	public boolean isItemInStock(String itemId) {
	    return itemMapper.getInventoryQuantity(itemId) > 0;
	}
	
	@Override 
	public List<Item> getItemList() {
		return itemMapper.getItemList();
	}	

	@Override 
	@Transactional
	public void insertOrder(Order order) {
	    order.setOrderId(getNextId("ordernum"));
	    for (int i = 0; i < order.getLineItems().size(); i++) {
	      LineItem lineItem = (LineItem) order.getLineItems().get(i);
	      String itemId = lineItem.getItemId();
	      Integer increment = new Integer(lineItem.getQuantity());
	      Map<String, Object> param = new HashMap<String, Object>(2);
	      param.put("itemId", itemId);
	      param.put("increment", increment);
	      itemMapper.updateInventoryQuantity(param);
	    }

	    orderMapper.insertOrder(order);
	    orderMapper.insertOrderStatus(order);
	    for (int i = 0; i < order.getLineItems().size(); i++) {
	      LineItem lineItem = (LineItem) order.getLineItems().get(i);
	      lineItem.setOrderId(order.getOrderId());
	      lineItemMapper.insertLineItem(lineItem);
	    }
	}

	@Override 
	@Transactional
	public Order getOrder(int orderId) {
	    Order order = orderMapper.getOrder(orderId);
	    order.setLineItems(lineItemMapper.getLineItemsByOrderId(orderId));

	    for (int i = 0; i < order.getLineItems().size(); i++) {
	      LineItem lineItem = (LineItem) order.getLineItems().get(i);
	      Item item = itemMapper.getItem(lineItem.getItemId());
	      item.setQuantity(itemMapper.getInventoryQuantity(lineItem.getItemId()));
	      lineItem.setItem(item);
	    }

	    return order;
	}

	@Override 
	public List<Order> getOrdersByUsername(String username) {
	    return orderMapper.getOrdersByUsername(username);
	}

	public int getNextId(String name) {
	    Sequence sequence = new Sequence(name, -1);
	    sequence = (Sequence) sequenceMapper.getSequence(sequence);
	    if (sequence == null) {
	      throw new RuntimeException("Error: A null sequence was returned from the database (could not get next " + name
	          + " sequence).");
	    }
	    Sequence parameterObject = new Sequence(name, sequence.getNextId() + 1);
	    sequenceMapper.updateSequence(parameterObject);
	    return sequence.getNextId();
	}
	
}